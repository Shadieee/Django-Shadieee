from django.urls import path
from . import views

urlpatterns = [
    path('create-user/', views.home, name='create_user'),
] 