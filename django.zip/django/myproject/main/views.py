from django.shortcuts import render
from django.http import HttpResponse
from .models import UserProfile
# from django.views.decorators.csrf import csrf_exempt # We will use DRF's view decorators instead

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import UserProfileSerializer

# Create your views here.
# @csrf_exempt # Not needed with @api_view for this use case
@api_view(['GET', 'POST'])
def home(request):
    if request.method == 'POST':
        serializer = UserProfileSerializer(data=request.data)
        if serializer.is_valid():
            # Create only a UserProfile object
            serializer.save()
            # Return a success JSON response
            return Response({"message": "User information saved successfully!"}, status=status.HTTP_201_CREATED)
        # Return a JSON response with validation errors and a 400 status code
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Handle GET requests for the login page
    # Note: If you want to render HTML for GET requests, this part needs more integration with DRF
    # For a pure API endpoint, you might return data here or raise a MethodNotAllowed
    return render(request, 'main/login.html')
